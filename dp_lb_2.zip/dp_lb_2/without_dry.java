/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dp_lb_2;

/**
 *
 * @author fa20-bse-036
 */
public class without_dry {
    public static void main(String[] args) {
        String employee1Name = "John Doe";
        int employee1Salary = 50000;
        String employee2Name = "Jane Smith";
        int employee2Salary = 60000;

        System.out.println("Employee 1: " + employee1Name + ", Salary: $" + employee1Salary);
        System.out.println("Employee 2: " + employee2Name + ", Salary: $" + employee2Salary);
    }
}

